# Claude Code Prompt Template

Copy and paste this into Claude Code to start the implementation.

---

## Initial Setup Prompt

```
I need you to implement a Kubernetes bootstrap system with k6 and Playwright testing.

I have created a detailed specification document called BOOTSTRAP_SETUP_INSTRUCTIONS.md.
Please read this file completely before starting any implementation.

CRITICAL REQUIREMENTS:
1. Follow the instructions in BOOTSTRAP_SETUP_INSTRUCTIONS.md EXACTLY
2. Implement ONE phase at a time
3. Ask me to verify BEFORE moving to the next phase
4. Create working code only - NO markdown files except README.md
5. Make all scripts executable
6. Every script must be idempotent (can run multiple times safely)

Start by reading BOOTSTRAP_SETUP_INSTRUCTIONS.md and confirming you understand the requirements.
Then implement Phase 1 (Project Structure) and ask me to verify with: tree -L 2 bootstrap-system/

Do not proceed to Phase 2 until I confirm Phase 1 is correct.
```

---

## For Individual Script Implementation

Use this when Claude Code needs to create or update a specific script:

```
Update [SCRIPT_NAME] to [SPECIFIC REQUIREMENT].

Requirements:
1. Must be idempotent (can run multiple times)
2. Must exit with error code on failure
3. Must provide clear error messages
4. Use functions from scripts/lib/common.sh for logging
5. Must pass this test: [SPECIFIC TEST COMMAND]

Create working code only. No markdown files. No explanations unless I ask.

After implementation, show me the complete script so I can review it.
```

---

## For Test Creation

Use this when creating k6 or Playwright tests:

```
Create [TEST_FILE_PATH] that tests [SPECIFIC FUNCTIONALITY].

Requirements:
1. Must provide clear pass/fail output
2. Must have meaningful thresholds (for k6)
3. Must handle authentication if needed
4. Must be runnable standalone: [COMMAND TO RUN]

Test acceptance criteria:
- [SPECIFIC CHECK 1]
- [SPECIFIC CHECK 2]
- [SPECIFIC CHECK 3]

Show me the complete test code when done.
```

---

## For Debugging

Use this when something isn't working:

```
This command failed: [COMMAND]

Error output:
[PASTE ERROR OUTPUT]

Current state:
[DESCRIBE WHAT YOU'VE DONE]

Debug this issue:
1. Identify the root cause
2. Suggest ONE fix (not multiple options)
3. Show me the exact change needed
4. Explain how to verify the fix

Do not create backup files or markdown notes.
```

---

## For Feature Addition

Use this after the system is working and you want to add something:

```
Add [FEATURE] to the bootstrap system.

This requires:
1. Update [SCRIPT_NAME] to [CHANGE]
2. Add test [TEST_FILE] that verifies [FUNCTIONALITY]
3. Update Makefile with target: make [NEW_TARGET]
4. Update README.md with usage example

Acceptance criteria:
- make test still passes
- New feature is tested
- No AI-generated markdown artifacts

Implement one step at a time and ask me to verify before proceeding.
```

---

## For Cleanup

Use this when Claude Code has made a mess:

```
Clean up this repository:

1. Remove all files matching:
   - *-working.md
   - *-fixed*.md
   - *-backup*
   - Any other AI-generated markdown beyond README.md

2. List files you're about to delete
3. Wait for my confirmation
4. Delete confirmed files

Do not delete:
- README.md
- BOOTSTRAP_SETUP_INSTRUCTIONS.md
- Any .yaml, .sh, .js, .ts files
```

---

## Example Session Flow

### Good Session
```
ME: [paste initial setup prompt]

CLAUDE: I've read BOOTSTRAP_SETUP_INSTRUCTIONS.md. I'll start with Phase 1.
        [creates directory structure]
        Please verify with: tree -L 2 bootstrap-system/

ME: ✓ Looks good

CLAUDE: Moving to Phase 2: Configuration files.
        [creates config files]
        Please create config/proxmox.yaml and confirm.

ME: ✓ Created

CLAUDE: Moving to Phase 3: Bootstrap script.
        [creates bootstrap.sh and common.sh]
        Please verify with: ./bootstrap.sh --help

ME: ✓ Works

[... continues one phase at a time ...]
```

### Bad Session (what to avoid)
```
ME: "Help me set up ArgoCD"

CLAUDE: [creates 10 files at once, adds markdown explanations, doesn't ask for verification]

ME: "This is too much, slow down"

CLAUDE: [creates implementation-notes.md, architecture-working.md]

[... becomes a mess ...]
```

---

## Common Mistakes to Correct

### Mistake: Claude Code creates markdown files

```
Stop. You created these files:
- implementation-notes.md
- architecture-working.md

Delete these immediately. I only want:
- Working code (.sh, .js, .ts, .yaml)
- README.md for documentation

No other markdown files. Confirm deletion.
```

### Mistake: Claude Code implements everything at once

```
Stop. You implemented Phases 1-5 without asking for verification.

This is wrong. We need to:
1. Rollback: git reset --hard HEAD
2. Start over from Phase 1
3. ONE phase at a time
4. Wait for my verification before proceeding

Let's start again with Phase 1 only.
```

### Mistake: Claude Code asks too many questions

```
You're asking too many questions. Just implement Phase [N] as specified in 
BOOTSTRAP_SETUP_INSTRUCTIONS.md.

If something is unclear, implement the most reasonable solution and show me.
I'll tell you if it needs changes.

Don't ask for confirmation on every decision. Just implement and show me the result.
```

---

## Verification Commands Reference

Copy-paste these to verify each phase:

### Phase 1: Structure
```bash
tree -L 2 bootstrap-system/
```

### Phase 2: Config
```bash
cat config/config.example.yaml
cat config/local.yaml
# I create: config/proxmox.yaml
```

### Phase 3: Bootstrap Script
```bash
chmod +x bootstrap.sh scripts/*.sh
./bootstrap.sh --help
```

### Phase 4: Scripts
```bash
# Test each script individually
bash -x scripts/01-cluster-setup.sh local config/local.yaml
bash -x scripts/02-core-infra.sh config/local.yaml
# etc...
```

### Phase 5: k6 Tests
```bash
k6 version
k6 run tests/k6/argocd-health.js --no-color
```

### Phase 6: Playwright Tests
```bash
npm install
npx playwright install chromium
npm test
```

### Phase 7: Makefile
```bash
make help
make deps
```

### Phase 8: Git
```bash
git status
git log --oneline
git tag
```

### Phase 9: Full System
```bash
make bootstrap CONFIG=config/local.yaml
make test
```

---

## Final Checklist Before Considering It Done

- [ ] All phases implemented
- [ ] All tests pass: `make test`
- [ ] No markdown files except README.md
- [ ] No files with -working, -fixed, -backup suffixes
- [ ] Git history is clean
- [ ] Tagged with v1.0: `git tag v1.0-verified`
- [ ] Works on local cluster
- [ ] Works on Proxmox cluster

---

## Tips for Best Results

1. **Be specific**: Don't say "set up testing", say "create tests/k6/argocd-health.js with these specific checks"

2. **One thing at a time**: Don't ask for "the whole bootstrap system", ask for "Phase 1 directory structure"

3. **Provide acceptance criteria**: "Must pass: make test-bootstrap" not "make it work"

4. **Show errors**: Paste actual error output, don't describe it

5. **Demand working code**: "No markdown files" should be in every prompt

6. **Verify incrementally**: Check each phase before moving on

7. **Use the Makefile**: Reference Make targets as acceptance criteria

8. **Tag working states**: After each successful phase: `git tag v0.x-phase-name`

---

## When You're Stuck

If Claude Code isn't following instructions:

```
RESET. 

You are not following BOOTSTRAP_SETUP_INSTRUCTIONS.md correctly.

Please:
1. Re-read the instructions
2. Delete any files that don't match the spec
3. Start over from the current phase
4. ONE step at a time
5. ASK ME TO VERIFY before proceeding

Do not create markdown files.
Do not implement multiple phases at once.
Do not create backup files.

Confirm you understand, then resume from Phase [N].
```

---

**Remember:** The goal is working, tested code. Not explanations. Not documentation. Just code that passes `make test`.
