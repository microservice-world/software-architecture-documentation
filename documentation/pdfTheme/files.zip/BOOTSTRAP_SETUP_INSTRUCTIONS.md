# Bootstrap System Setup Instructions

**CRITICAL CONTEXT:**
I am a Kubernetes consultant managing multiple SaaS projects. I need a trustworthy, testable bootstrap system for deploying ArgoCD-based infrastructure with optional Velero restore capabilities. I use k6 and Playwright as my trust anchors - if tests pass, I trust the deployment.

**CURRENT STATE:**
- I have a Proxmox cluster with Kubernetes already running
- I have a kubeconfig file that can access this cluster
- I need to start with LOCAL testing (k3s/kind) before touching production
- I have scattered repositories and no consistent deployment process
- I don't trust AI-generated code without automated test verification

**DESIRED END STATE:**
- Single command bootstrap: `./bootstrap.sh <cluster-name>`
- Automated testing with k6 (API/health) and Playwright (E2E)
- Clean git history with tagged releases
- No AI-generated markdown artifacts cluttering the repo
- Confidence to deploy to production based on test results

---

## Phase 1: Project Structure Setup

**REQUIREMENT:** Create a clean, organized project structure.

**DO:**
1. Create this directory structure:
```
bootstrap-system/
├── bootstrap.sh              # Main entry point
├── config/
│   ├── local.yaml           # Local k3s/kind config
│   ├── proxmox.yaml         # Proxmox cluster config (I'll provide)
│   └── config.example.yaml  # Template
├── scripts/
│   ├── 01-cluster-setup.sh
│   ├── 02-core-infra.sh
│   ├── 03-deploy-argocd.sh
│   ├── 04-velero-restore.sh
│   ├── 05-argocd-bootstrap.sh
│   └── lib/
│       └── common.sh        # Shared functions
├── tests/
│   ├── k6/
│   │   ├── argocd-health.js
│   │   ├── apps-health.js
│   │   └── lib/
│   │       └── helpers.js
│   └── e2e/
│       ├── playwright.config.ts
│       ├── argocd-login.spec.ts
│       └── apps-health.spec.ts
├── argocd/
│   ├── bootstrap/
│   │   └── applications.yaml
│   └── apps/
│       └── (ArgoCD Application manifests)
├── Makefile                  # Command interface
├── .gitignore
├── package.json             # For Playwright
└── README.md
```

2. Initialize git repository:
```bash
git init
git add .
git commit -m "initial: project structure"
git tag v0.1-structure
```

**DO NOT:**
- Create any markdown files with names like "implementation-notes.md", "architecture-working.md", etc.
- Create backup copies of scripts with suffixes like "-fixed", "-working", "-v2"
- Add explanatory markdown beyond README.md

**VERIFICATION:**
Ask me to run: `tree -L 2 bootstrap-system/` and confirm structure matches.

---

## Phase 2: Configuration System

**REQUIREMENT:** Multi-environment configuration with sane defaults.

**DO:**
Create `config/config.example.yaml`:
```yaml
# Configuration for bootstrap system
cluster:
  name: local
  type: k3s  # k3s, kind, or remote
  
  # For remote clusters (like Proxmox)
  kubeconfig: ~/.kube/config
  context: default  # kubectl context name

argocd:
  namespace: argocd
  version: v2.9.3
  domain: argocd.local.dev
  admin_password: changeme  # Will be auto-generated if empty
  
  # Git repository for ArgoCD apps
  repo_url: https://github.com/YOUR_USERNAME/YOUR_REPO
  repo_path: argocd/apps
  target_revision: HEAD

velero:
  enabled: false
  namespace: velero
  backup_location: s3://your-bucket/velero
  restore_name: ""  # Leave empty for fresh install

core_infra:
  cert_manager:
    enabled: true
    version: v1.13.0
  
  ingress_nginx:
    enabled: true
    version: v1.9.0

testing:
  k6:
    vus: 1
    duration: 30s
  
  playwright:
    headless: true
    timeout: 30000
```

Create `config/local.yaml`:
```yaml
cluster:
  name: local
  type: k3s

argocd:
  domain: argocd.localhost

testing:
  skip_e2e: true  # Faster local testing
```

**DO NOT:**
- Hardcode credentials
- Create multiple "backup" config files

**VERIFICATION:**
I will create `config/proxmox.yaml` with my cluster details. Ask me to confirm it exists before proceeding.

---

## Phase 3: Core Bootstrap Script

**REQUIREMENT:** Main entry point that orchestrates everything and provides clear feedback.

**DO:**
Create `bootstrap.sh`:
```bash
#!/usr/bin/env bash
set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${2:-config/local.yaml}"
CLUSTER_NAME="${1:-local}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Source common functions
source "${SCRIPT_DIR}/scripts/lib/common.sh"

# Load configuration
load_config "$CONFIG_FILE"

log_info "Bootstrap starting for cluster: $CLUSTER_NAME"
log_info "Using config: $CONFIG_FILE"

# Phase 1: Cluster Setup
log_phase "1/5: Cluster Setup"
"${SCRIPT_DIR}/scripts/01-cluster-setup.sh" "$CLUSTER_NAME" "$CONFIG_FILE"

# Phase 2: Core Infrastructure
log_phase "2/5: Core Infrastructure"
"${SCRIPT_DIR}/scripts/02-core-infra.sh" "$CONFIG_FILE"

# Phase 3: ArgoCD Deployment
log_phase "3/5: ArgoCD Deployment"
"${SCRIPT_DIR}/scripts/03-deploy-argocd.sh" "$CONFIG_FILE"

# Phase 4: Velero (optional)
if [ "$(get_config 'velero.enabled')" = "true" ]; then
    log_phase "4/5: Velero Restore"
    "${SCRIPT_DIR}/scripts/04-velero-restore.sh" "$CONFIG_FILE"
else
    log_info "Velero disabled, skipping..."
fi

# Phase 5: Bootstrap Applications
log_phase "5/5: Bootstrap Applications"
"${SCRIPT_DIR}/scripts/05-argocd-bootstrap.sh" "$CONFIG_FILE"

log_success "Bootstrap complete!"
log_info "Next steps:"
echo "  1. Run tests: make test-bootstrap"
echo "  2. Verify in ArgoCD UI: https://$(get_config 'argocd.domain')"
echo "  3. If tests pass, tag release: git tag v1.0-verified"
```

Create `scripts/lib/common.sh`:
```bash
#!/usr/bin/env bash

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_phase() {
    echo -e "\n${YELLOW}=== $1 ===${NC}\n"
}

# Configuration helpers
load_config() {
    local config_file=$1
    if [ ! -f "$config_file" ]; then
        log_error "Config file not found: $config_file"
        exit 1
    fi
    # Export config for scripts to use
    export CONFIG_FILE=$config_file
}

get_config() {
    local key=$1
    # Use yq to parse YAML
    yq eval ".$key" "$CONFIG_FILE"
}

# Kubernetes helpers
wait_for_pods() {
    local namespace=$1
    local label=$2
    local timeout=${3:-300}
    
    log_info "Waiting for pods in $namespace with label $label..."
    kubectl wait --for=condition=ready pod \
        -l "$label" \
        -n "$namespace" \
        --timeout="${timeout}s"
}
```

**REQUIREMENTS:**
- Each script phase must be idempotent (can run multiple times safely)
- Use `set -euo pipefail` in all bash scripts
- Provide clear progress indicators
- Exit with meaningful error messages

**DO NOT:**
- Create functions in bootstrap.sh - put them in common.sh
- Add inline documentation comments explaining every line
- Create multiple versions of bootstrap.sh

**VERIFICATION:**
After implementation, ask me to run:
```bash
./bootstrap.sh --help  # Should show usage
chmod +x bootstrap.sh scripts/*.sh  # If not executable
```

---

## Phase 4: Testing Framework - k6

**REQUIREMENT:** k6 tests that verify infrastructure health and API responses.

**DO:**
Create `tests/k6/argocd-health.js`:
```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';
import { config } from './lib/helpers.js';

export const options = {
  vus: config.vus,
  duration: config.duration,
  thresholds: {
    http_req_failed: ['rate<0.01'],     // Less than 1% failures
    http_req_duration: ['p(95)<500'],   // 95% under 500ms
  },
};

export default function() {
  const argocdUrl = `https://${config.argocd.domain}`;
  
  // Test 1: Health endpoint
  const health = http.get(`${argocdUrl}/healthz`);
  check(health, {
    'ArgoCD health endpoint is up': (r) => r.status === 200,
  });

  // Test 2: API version (unauthenticated)
  const version = http.get(`${argocdUrl}/api/version`);
  check(version, {
    'ArgoCD API responds': (r) => r.status === 200,
    'Version is present': (r) => r.json('Version') !== undefined,
  });

  sleep(1);
}
```

Create `tests/k6/apps-health.js`:
```javascript
import http from 'k6/http';
import { check } from 'k6';
import { config, getArgoToken } from './lib/helpers.js';

export const options = {
  vus: 1,
  iterations: 1,
};

const token = getArgoToken();

export default function() {
  const argocdUrl = `https://${config.argocd.domain}`;
  
  const params = {
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  };

  // Get all applications
  const apps = http.get(`${argocdUrl}/api/v1/applications`, params);
  
  check(apps, {
    'Applications endpoint accessible': (r) => r.status === 200,
    'At least one app exists': (r) => r.json('items').length > 0,
  });

  // Check each application health
  const items = apps.json('items');
  items.forEach(app => {
    const appName = app.metadata.name;
    const health = app.status.health.status;
    const sync = app.status.sync.status;
    
    console.log(`${appName}: health=${health}, sync=${sync}`);
    
    check(app, {
      [`${appName} is healthy`]: () => health === 'Healthy',
      [`${appName} is synced`]: () => sync === 'Synced',
    });
  });
}
```

Create `tests/k6/lib/helpers.js`:
```javascript
import { exec } from 'k6/x/exec';
import yaml from 'k6/x/yaml';

// Load config from file
export const config = yaml.parse(open('../../../config/local.yaml'));

// Get ArgoCD token (requires argocd CLI)
export function getArgoToken() {
  const result = exec.command('argocd', [
    'account', 'generate-token',
    '--account', 'admin'
  ]);
  
  if (result.exitCode !== 0) {
    throw new Error('Failed to generate ArgoCD token');
  }
  
  return result.stdout.trim();
}
```

**REQUIREMENTS:**
- Tests must be runnable with: `k6 run tests/k6/argocd-health.js`
- Must provide clear pass/fail output
- Must have thresholds that define "acceptable"

**VERIFICATION:**
After setup, ask me to run:
```bash
k6 version
k6 run tests/k6/argocd-health.js --no-color
```

---

## Phase 5: Testing Framework - Playwright

**REQUIREMENT:** End-to-end tests that verify user-facing functionality.

**DO:**
Create `package.json`:
```json
{
  "name": "bootstrap-system-tests",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "test": "playwright test",
    "test:ui": "playwright test --ui",
    "test:headed": "playwright test --headed"
  },
  "devDependencies": {
    "@playwright/test": "^1.40.0"
  }
}
```

Create `tests/e2e/playwright.config.ts`:
```typescript
import { defineConfig, devices } from '@playwright/test';
import * as yaml from 'js-yaml';
import * as fs from 'fs';

// Load config
const configFile = process.env.CONFIG_FILE || 'config/local.yaml';
const config = yaml.load(fs.readFileSync(configFile, 'utf8'));

export default defineConfig({
  testDir: './',
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 1,
  reporter: 'html',
  
  use: {
    baseURL: `https://${config.argocd.domain}`,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
```

Create `tests/e2e/argocd-login.spec.ts`:
```typescript
import { test, expect } from '@playwright/test';

test.describe('ArgoCD Bootstrap Verification', () => {
  test('ArgoCD UI is accessible', async ({ page }) => {
    await page.goto('/');
    
    // Should see login page
    await expect(page.locator('input[name="username"]')).toBeVisible();
    await expect(page.locator('input[name="password"]')).toBeVisible();
  });

  test('can login to ArgoCD', async ({ page }) => {
    await page.goto('/');
    
    // Login (admin/password from config or auto-generated)
    await page.fill('input[name="username"]', 'admin');
    
    // Get password from kubectl secret
    // This assumes the test has access to kubectl
    await page.fill('input[name="password"]', process.env.ARGOCD_PASSWORD || 'changeme');
    
    await page.click('button[type="submit"]');
    
    // Should see applications page
    await expect(page.locator('text=Applications')).toBeVisible({ timeout: 10000 });
  });
});
```

Create `tests/e2e/apps-health.spec.ts`:
```typescript
import { test, expect } from '@playwright/test';

test.describe('Applications Health', () => {
  test.beforeEach(async ({ page }) => {
    // Login first
    await page.goto('/');
    await page.fill('input[name="username"]', 'admin');
    await page.fill('input[name="password"]', process.env.ARGOCD_PASSWORD || 'changeme');
    await page.click('button[type="submit"]');
    await expect(page.locator('text=Applications')).toBeVisible();
  });

  test('all applications are synced and healthy', async ({ page }) => {
    await page.goto('/applications');
    
    // Wait for applications to load
    await page.waitForSelector('.applications-list', { timeout: 10000 });
    
    // Get all application tiles
    const appTiles = await page.locator('.application-status-panel').all();
    
    expect(appTiles.length).toBeGreaterThan(0);
    
    for (const tile of appTiles) {
      // Check sync status
      const syncStatus = tile.locator('.application-status-panel__item-value').first();
      await expect(syncStatus).toContainText('Synced');
      
      // Check health status
      const healthStatus = tile.locator('.application-status-panel__item-value').nth(1);
      await expect(healthStatus).toContainText('Healthy');
    }
  });
});
```

**REQUIREMENTS:**
- Tests must be runnable with: `npm test`
- Must generate HTML report on failure
- Must take screenshots on failure
- Tests should be self-contained (handle login, cleanup)

**VERIFICATION:**
After setup, ask me to run:
```bash
npm install
npx playwright install chromium
npm test
```

---

## Phase 6: Makefile - Command Interface

**REQUIREMENT:** Single source of truth for all commands.

**DO:**
Create `Makefile`:
```makefile
.PHONY: help bootstrap test test-bootstrap test-e2e clean clean-claude deps

# Configuration
CONFIG ?= config/local.yaml
CLUSTER ?= local

help: ## Show this help
	@grep -E '^[a-zA-Z_-]+:.*?## .*$$' $(MAKEFILE_LIST) | sort | awk 'BEGIN {FS = ":.*?## "}; {printf "\033[36m%-20s\033[0m %s\n", $$1, $$2}'

deps: ## Install dependencies
	@echo "Installing k6..."
	@which k6 || (echo "Please install k6: https://k6.io/docs/get-started/installation/" && exit 1)
	@echo "Installing Playwright..."
	@npm install
	@npx playwright install chromium
	@echo "Installing yq..."
	@which yq || (echo "Please install yq: brew install yq or apt install yq" && exit 1)

bootstrap: ## Run full bootstrap (usage: make bootstrap CLUSTER=proxmox CONFIG=config/proxmox.yaml)
	@./bootstrap.sh $(CLUSTER) $(CONFIG)

test-bootstrap: ## Run k6 infrastructure tests
	@echo "Running k6 bootstrap verification..."
	@k6 run tests/k6/argocd-health.js
	@k6 run tests/k6/apps-health.js
	@echo "✓ Bootstrap tests passed"

test-e2e: ## Run Playwright E2E tests
	@echo "Running Playwright E2E tests..."
	@export CONFIG_FILE=$(CONFIG) && npm test
	@echo "✓ E2E tests passed"

test: test-bootstrap test-e2e ## Run all tests

clean-claude: ## Remove Claude-generated artifacts
	@echo "Cleaning Claude artifacts..."
	@find . -type f \( \
		-name "*-working.md" -o \
		-name "*-fixed*.md" -o \
		-name "*-backup*" -o \
		-name "*-notes.md" \
		\) -delete
	@echo "✓ Cleaned"

clean: ## Clean test artifacts and reports
	@rm -rf test-results/ playwright-report/ node_modules/
	@echo "✓ Test artifacts cleaned"

verify: bootstrap test ## Bootstrap and verify in one command
	@echo "✓ Bootstrap verified and ready for production"

tag: ## Tag current state (usage: make tag VERSION=1.0)
	@if [ -z "$(VERSION)" ]; then echo "Usage: make tag VERSION=1.0"; exit 1; fi
	@git tag -a v$(VERSION) -m "Release v$(VERSION)"
	@git push --tags
	@echo "✓ Tagged v$(VERSION)"
```

**REQUIREMENTS:**
- Every target must have a ## comment
- `make help` shows available commands
- Easy to understand, easy to extend
- No hidden complexity

**VERIFICATION:**
Ask me to run: `make help`

---

## Phase 7: README and Documentation

**REQUIREMENT:** Clear README that explains the system and how to use it.

**DO:**
Create `README.md`:
```markdown
# Bootstrap System

Single-command Kubernetes cluster bootstrap with ArgoCD and Velero restore capabilities.
Built for confidence through automated testing with k6 and Playwright.

## Quick Start

### Local Testing (k3s)
```bash
# Install dependencies
make deps

# Bootstrap local cluster
make bootstrap

# Verify with tests
make test

# If tests pass, you're ready for production
```

### Production (Proxmox)
```bash
# 1. Create config/proxmox.yaml with your cluster details
# 2. Bootstrap production
make bootstrap CLUSTER=proxmox CONFIG=config/proxmox.yaml

# 3. Verify
make test CONFIG=config/proxmox.yaml

# 4. If tests pass, tag it
make tag VERSION=1.0
```

## What Gets Deployed

1. **Core Infrastructure**
   - cert-manager (TLS certificates)
   - ingress-nginx (Ingress controller)

2. **ArgoCD**
   - GitOps deployment system
   - Auto-sync from your repository

3. **Applications** (via ArgoCD)
   - Whatever you define in `argocd/apps/`

4. **Optional: Velero Restore**
   - Restore from backup if configured

## Trust Through Testing

This system uses automated tests as the source of truth:

- **k6 tests** verify API health and infrastructure
- **Playwright tests** verify UI and user flows
- **If tests pass, deployment is trustworthy**

```bash
# Run tests anytime
make test-bootstrap  # Infrastructure tests
make test-e2e       # End-to-end tests
make test           # All tests
```

## Configuration

Copy `config/config.example.yaml` to `config/proxmox.yaml` and customize:

```yaml
cluster:
  name: my-cluster
  type: remote
  kubeconfig: ~/.kube/proxmox-config
  context: kubernetes-admin@kubernetes

argocd:
  domain: argocd.mydomain.com
  repo_url: https://github.com/myorg/myrepo
```

## Directory Structure

```
bootstrap-system/
├── bootstrap.sh          # Main entry point
├── scripts/              # Phase scripts
├── tests/k6/            # Infrastructure tests
├── tests/e2e/           # Playwright E2E tests
├── config/              # Environment configs
└── argocd/              # ArgoCD app definitions
```

## Workflow

1. **Develop locally**: `make bootstrap CONFIG=config/local.yaml`
2. **Test locally**: `make test`
3. **Deploy to production**: `make bootstrap CONFIG=config/proxmox.yaml`
4. **Verify production**: `make test CONFIG=config/proxmox.yaml`
5. **Tag release**: `make tag VERSION=1.0`

## Troubleshooting

### Tests fail
```bash
# Check what's wrong
kubectl get pods --all-namespaces
kubectl logs -n argocd deployment/argocd-server

# Re-run specific test
k6 run tests/k6/argocd-health.js
npm test -- argocd-login.spec.ts
```

### Clean slate
```bash
# Delete everything and start over
k3d cluster delete local
make bootstrap
```

## Development

When working with Claude Code or AI assistants:

1. **Demand working code only**: "No markdown files, working code"
2. **Use tests as acceptance criteria**: "Must pass make test-bootstrap"
3. **Clean up after**: `make clean-claude` before committing
4. **Tag working states**: `git tag v0.x-working-feature`

## License

MIT
```

**DO NOT:**
- Write an essay
- Include implementation details (that's what code comments are for)
- Create separate architecture documents

**VERIFICATION:**
Ask me to review the README and confirm it's clear.

---

## Phase 8: Git Setup

**REQUIREMENT:** Clean git history with meaningful commits.

**DO:**
Create `.gitignore`:
```
# Node
node_modules/
package-lock.json

# Test artifacts
test-results/
playwright-report/
*.log

# k6 outputs
summary.json

# Secrets
*.key
*.pem
config/*-secrets.yaml

# Claude artifacts
*-working.md
*-fixed*.md
*-backup*
*-notes.md

# OS
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo
```

Initialize repository:
```bash
git init
git add .
git commit -m "initial: complete bootstrap system with testing"
git tag v0.1-initial
```

**VERIFICATION:**
Ask me to run: `git status` should be clean.

---

## Implementation Steps for Claude

**YOU MUST FOLLOW THESE STEPS IN ORDER:**

### Step 1: Structure
1. Create directory structure from Phase 1
2. Ask me to verify: `tree -L 2 bootstrap-system/`
3. Wait for my confirmation before proceeding

### Step 2: Configuration
1. Create config files from Phase 2
2. Ask me to create `config/proxmox.yaml` with my cluster details
3. Wait for confirmation before proceeding

### Step 3: Bootstrap Script
1. Create `bootstrap.sh` and `scripts/lib/common.sh` from Phase 3
2. Make all scripts executable
3. Ask me to test: `./bootstrap.sh --help`
4. Wait for confirmation

### Step 4: Individual Phase Scripts
For EACH script in `scripts/`:
1. Implement one script at a time
2. Show me the script content
3. Ask me to review before moving to next script
4. DO NOT implement all scripts at once

### Step 5: k6 Tests
1. Create k6 test structure from Phase 4
2. Ask me to verify k6 is installed
3. Test with: `k6 run tests/k6/argocd-health.js --no-color`

### Step 6: Playwright Tests
1. Create Playwright test structure from Phase 5
2. Ask me to run: `npm install && npx playwright install chromium`
3. Test with: `npm test`

### Step 7: Makefile
1. Create Makefile from Phase 6
2. Ask me to run: `make help`
3. Wait for confirmation all targets work

### Step 8: Documentation
1. Create README and .gitignore from Phase 7 and 8
2. Ask me to review
3. Initialize git with initial commit

### Step 9: End-to-End Verification
1. Ask me to run: `make bootstrap CONFIG=config/local.yaml`
2. Ask me to run: `make test`
3. If tests pass, ask me to tag: `git tag v1.0-verified`

---

## Critical Requirements

**MUST DO:**
✅ Implement one phase at a time
✅ Ask for verification at each step
✅ Make scripts idempotent
✅ Provide clear error messages
✅ Use tests as acceptance criteria

**MUST NOT DO:**
❌ Create markdown files beyond README.md
❌ Implement everything without verification
❌ Create "backup" or "working" versions of files
❌ Skip testing steps
❌ Hardcode credentials

---

## Success Criteria

The bootstrap system is complete when:

1. ✅ `make bootstrap` deploys everything
2. ✅ `make test-bootstrap` passes (k6)
3. ✅ `make test-e2e` passes (Playwright)
4. ✅ Git history is clean with no AI artifacts
5. ✅ I can switch between local and Proxmox with config files
6. ✅ I trust the system because tests verify it works

---

## Questions I May Ask You

**"What does this script do?"**
→ Show me the script and explain in 2-3 sentences

**"Why did the test fail?"**
→ Show me the error output and suggest ONE fix

**"Can we add feature X?"**
→ Confirm you understand, then update relevant files

**"This doesn't work"**
→ Ask me for error output, then diagnose

---

## Final Notes

- I will be running these commands on my local Arch Linux machine
- I use Doom Emacs but will run commands in terminal
- I have kubectl, k6, and npm already available
- My Proxmox cluster config is at `~/.kube/proxmox-config`
- I need this system working TODAY - be efficient but thorough

**Start with Phase 1 (Project Structure) and ask me to verify before proceeding.**
