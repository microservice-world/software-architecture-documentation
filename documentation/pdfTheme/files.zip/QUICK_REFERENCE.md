# Bootstrap System - Quick Reference Card

Keep this handy for daily operations.

---

## Daily Workflow

### 1. Local Development & Testing
```bash
# Start fresh local cluster
make bootstrap

# Test everything
make test

# If tests pass, you can trust it
```

### 2. Deploy to Production
```bash
# Deploy to Proxmox
make bootstrap CONFIG=config/proxmox.yaml

# Verify it works
make test CONFIG=config/proxmox.yaml

# Tag successful deployment
make tag VERSION=1.0
```

### 3. After Working with Claude Code
```bash
# Clean up AI-generated clutter
make clean-claude

# Verify nothing important was deleted
git status

# Commit clean code
git add -A
git commit -m "feat: whatever Claude helped with"
```

---

## Common Commands

### Bootstrap Operations
```bash
make help                    # Show all available commands
make deps                    # Install required tools
make bootstrap               # Deploy to local cluster
make bootstrap CONFIG=...    # Deploy to specific cluster
make verify                  # Bootstrap + test in one command
```

### Testing
```bash
make test-bootstrap          # k6 infrastructure tests only
make test-e2e               # Playwright E2E tests only
make test                   # All tests
```

### Maintenance
```bash
make clean                  # Remove test artifacts
make clean-claude           # Remove AI-generated junk
```

### Tagging & Versioning
```bash
make tag VERSION=1.0        # Tag current state
git tag                     # List all tags
git checkout v1.0           # Revert to tagged version
```

---

## Configuration Files

### Local Development
```bash
config/local.yaml
```
- Uses k3s or kind
- Fast iteration
- Safe to break

### Production (Proxmox)
```bash
config/proxmox.yaml
```
- Uses your real cluster
- Requires kubeconfig
- TEST FIRST with local

---

## Troubleshooting Quick Fixes

### "Tests fail but I don't know why"
```bash
# Run with verbose output
k6 run tests/k6/argocd-health.js --verbose

# Or for Playwright
npm run test:headed
```

### "ArgoCD won't deploy"
```bash
# Check pods
kubectl get pods -n argocd

# Check logs
kubectl logs -n argocd deployment/argocd-server

# Delete and retry
kubectl delete namespace argocd
make bootstrap
```

### "I messed everything up"
```bash
# Nuclear option - start over
k3d cluster delete local
make bootstrap
make test
```

### "Can't remember what works"
```bash
# List all tagged versions
git tag -l

# See what's in a working version
git show v1.0:bootstrap.sh
```

---

## File Locations

### Scripts
```
bootstrap.sh              # Main entry point
scripts/01-cluster-setup.sh
scripts/02-core-infra.sh
scripts/03-deploy-argocd.sh
scripts/04-velero-restore.sh
scripts/05-argocd-bootstrap.sh
scripts/lib/common.sh     # Shared functions
```

### Tests
```
tests/k6/argocd-health.js     # Infrastructure health
tests/k6/apps-health.js       # Application health
tests/e2e/argocd-login.spec.ts
tests/e2e/apps-health.spec.ts
```

### Config
```
config/local.yaml        # Local k3s/kind
config/proxmox.yaml      # Your production cluster
config/config.example.yaml  # Template
```

---

## Working with Claude Code

### Good Prompts
```
✅ "Update 03-deploy-argocd.sh to use kustomize. No markdown files."
✅ "Add k6 test for ingress controller health. Must pass before proceeding."
✅ "Fix this error: [paste error]. Working code only."
```

### Bad Prompts
```
❌ "Help me with ArgoCD"  (too vague)
❌ "Explain what this does"  (you need code, not explanations)
❌ "Make it better"  (no clear acceptance criteria)
```

### After Every Claude Code Session
```bash
# 1. Clean up
make clean-claude

# 2. Test
make test

# 3. If tests pass, commit
git add -A
git commit -m "wip: [what you worked on]"

# 4. If everything works, tag it
git tag v0.x-working-feature
```

---

## Trust Verification Process

```
┌─────────────────────────────────────┐
│ 1. Make a change (manually or AI)  │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│ 2. Run: make test                   │
└──────────────┬──────────────────────┘
               │
         ┌─────┴─────┐
         │           │
         ▼           ▼
    ┌────────┐  ┌────────┐
    │ PASS   │  │ FAIL   │
    └────┬───┘  └───┬────┘
         │          │
         │          ▼
         │    ┌──────────────┐
         │    │ Fix & retry  │
         │    └──────┬───────┘
         │           │
         └───────────┘
                │
                ▼
      ┌──────────────────┐
      │ 3. Commit & tag  │
      └──────────────────┘
                │
                ▼
      ┌──────────────────┐
      │ 4. Trust it      │
      └──────────────────┘
```

**Key Insight:** You only trust code that passes tests, not code that "looks good" or "Claude explained well".

---

## What Success Looks Like

### After v1.0
- ✅ One command deploys everything: `make bootstrap`
- ✅ Tests verify it works: `make test`
- ✅ Git history is clean (no AI junk)
- ✅ Can switch between local/proxmox easily
- ✅ Confident deploying to production

### When Adding New Tools
```bash
# 1. Add app definition to argocd/apps/my-tool.yaml
# 2. Add k6 test: tests/k6/my-tool-health.js
# 3. Add E2E test: tests/e2e/my-tool.spec.ts
# 4. Bootstrap: make bootstrap
# 5. Verify: make test
# 6. If tests pass → deploy to production
```

---

## Emergency Rollback

### If production deployment breaks:

```bash
# 1. Find last working tag
git tag -l

# 2. Checkout that version
git checkout v0.9-working

# 3. Redeploy
make bootstrap CONFIG=config/proxmox.yaml

# 4. Verify
make test CONFIG=config/proxmox.yaml

# 5. Fix the issue on a branch
git checkout -b fix/production-issue
# ... make fixes ...
make test  # until it passes
git commit -m "fix: production issue"
git tag v1.0-fixed
```

---

## Metrics That Matter

Track these to know if system is working:

1. **Time to deploy**: How long does `make bootstrap` take?
   - Local: ~5 minutes
   - Proxmox: ~10 minutes

2. **Test success rate**: Do tests pass consistently?
   - Target: >95% pass rate

3. **Recovery time**: How fast can you rollback?
   - Should be: <5 minutes (checkout tag + redeploy)

4. **Trust level**: Can you deploy without manual verification?
   - Goal: Yes, if `make test` passes

---

## When to Use Each Test Type

### k6 Tests (Infrastructure)
Use for:
- "Is ArgoCD running?"
- "Can I reach the API?"
- "Are all apps healthy?"
- Quick smoke tests

Run with: `make test-bootstrap`

### Playwright Tests (E2E)
Use for:
- "Can users login?"
- "Do critical flows work?"
- "Is the UI functional?"
- Deep integration verification

Run with: `make test-e2e`

### Combined
Use for:
- Pre-production verification
- Release qualification
- After major changes

Run with: `make test`

---

## File to Keep Handy

```bash
# Print this reference anytime
cat QUICK_REFERENCE.md

# Or bookmark these locations
bootstrap.sh              # If deployment fails
Makefile                  # If you forget commands
config/proxmox.yaml       # If config is wrong
tests/k6/                 # If infrastructure tests fail
tests/e2e/                # If E2E tests fail
```

---

## Remember

1. **Tests are truth** - Not explanations, not assumptions
2. **Tag working states** - Makes rollback trivial
3. **Clean regularly** - `make clean-claude` before commits
4. **Local first** - Test locally before Proxmox
5. **Trust the process** - If tests pass, it works

---

**Last Updated:** 2024-12-21
**Version:** 1.0
