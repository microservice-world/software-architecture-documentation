# Bootstrap System Implementation Checklist

Use this checklist to track progress as Claude Code implements the system.

## Pre-Implementation Checks

- [ ] Read BOOTSTRAP_SETUP_INSTRUCTIONS.md completely
- [ ] Confirm k6 is installed: `k6 version`
- [ ] Confirm npm is installed: `npm --version`
- [ ] Confirm kubectl works: `kubectl version --client`
- [ ] Confirm yq is installed: `yq --version`
- [ ] Have Proxmox kubeconfig ready: `~/.kube/proxmox-config`

---

## Phase 1: Project Structure ✓/✗

- [ ] Directory structure created
- [ ] Verified with `tree -L 2 bootstrap-system/`
- [ ] All directories present
- [ ] Git initialized

**Verification Command:**
```bash
cd bootstrap-system && tree -L 2
```

**Expected Output:**
```
bootstrap-system/
├── config/
├── scripts/
│   └── lib/
├── tests/
│   ├── k6/
│   │   └── lib/
│   └── e2e/
├── argocd/
│   ├── bootstrap/
│   └── apps/
├── bootstrap.sh
└── Makefile
```

---

## Phase 2: Configuration Files ✓/✗

- [ ] `config/config.example.yaml` created
- [ ] `config/local.yaml` created
- [ ] Created `config/proxmox.yaml` from template
- [ ] Filled in Proxmox kubeconfig path
- [ ] Filled in kubectl context name
- [ ] Filled in ArgoCD domain

**Verification Command:**
```bash
cat config/proxmox.yaml | grep -E "kubeconfig|context|domain"
```

**My Proxmox Config:**
```yaml
cluster:
  kubeconfig: ~/.kube/proxmox-config
  context: [I WILL FILL THIS IN]

argocd:
  domain: [I WILL FILL THIS IN]
```

---

## Phase 3: Bootstrap Script ✓/✗

- [ ] `bootstrap.sh` created
- [ ] `scripts/lib/common.sh` created
- [ ] Scripts are executable
- [ ] `bootstrap.sh --help` shows usage
- [ ] Logging functions work

**Verification Command:**
```bash
chmod +x bootstrap.sh scripts/*.sh
./bootstrap.sh --help
```

**Expected Output:**
Should show usage information or available options.

---

## Phase 4: Individual Phase Scripts ✓/✗

Complete ONE at a time, verify each before moving to next:

- [ ] `scripts/01-cluster-setup.sh` implemented
  - [ ] Reviewed code
  - [ ] Tested locally
  
- [ ] `scripts/02-core-infra.sh` implemented
  - [ ] Reviewed code
  - [ ] Tested locally
  
- [ ] `scripts/03-deploy-argocd.sh` implemented
  - [ ] Reviewed code
  - [ ] Tested locally
  
- [ ] `scripts/04-velero-restore.sh` implemented
  - [ ] Reviewed code
  - [ ] Tested locally
  
- [ ] `scripts/05-argocd-bootstrap.sh` implemented
  - [ ] Reviewed code
  - [ ] Tested locally

**Verification Per Script:**
```bash
# Test script independently
bash -x scripts/01-cluster-setup.sh local config/local.yaml
```

---

## Phase 5: k6 Testing Framework ✓/✗

- [ ] `tests/k6/argocd-health.js` created
- [ ] `tests/k6/apps-health.js` created
- [ ] `tests/k6/lib/helpers.js` created
- [ ] k6 tests are runnable
- [ ] Tests provide clear output

**Verification Command:**
```bash
k6 run tests/k6/argocd-health.js --no-color
```

**Expected Output:**
```
     ✓ ArgoCD health endpoint is up
     ✓ ArgoCD API responds
     ✓ Version is present
```

---

## Phase 6: Playwright Testing Framework ✓/✗

- [ ] `package.json` created
- [ ] `tests/e2e/playwright.config.ts` created
- [ ] `tests/e2e/argocd-login.spec.ts` created
- [ ] `tests/e2e/apps-health.spec.ts` created
- [ ] Dependencies installed: `npm install`
- [ ] Playwright installed: `npx playwright install chromium`
- [ ] Tests are runnable

**Verification Command:**
```bash
npm install
npx playwright install chromium
npm test
```

**Expected Output:**
```
Running 3 tests using 1 worker
  ✓ ArgoCD UI is accessible
  ✓ can login to ArgoCD
  ✓ all applications are synced and healthy
```

---

## Phase 7: Makefile ✓/✗

- [ ] `Makefile` created
- [ ] All targets have help text
- [ ] `make help` works
- [ ] Each target is tested individually

**Verification Command:**
```bash
make help
```

**Test Each Target:**
```bash
make deps         # Should check/install dependencies
make clean-claude # Should remove AI artifacts
make clean        # Should remove test artifacts
```

---

## Phase 8: Documentation ✓/✗

- [ ] `README.md` created
- [ ] `.gitignore` created
- [ ] Git repository initialized
- [ ] Initial commit made
- [ ] Initial tag created

**Verification Commands:**
```bash
cat README.md | head -20
git log --oneline
git tag
```

**Expected:**
- README has clear quick start
- Git has initial commit
- Tag `v0.1-initial` exists

---

## Phase 9: End-to-End Verification ✓/✗

### Local Testing (k3s)

- [ ] Local cluster created
- [ ] Bootstrap runs: `make bootstrap CONFIG=config/local.yaml`
- [ ] k6 tests pass: `make test-bootstrap`
- [ ] Playwright tests pass: `make test-e2e`
- [ ] All tests pass: `make test`

**Full Verification:**
```bash
make bootstrap CONFIG=config/local.yaml
make test CONFIG=config/local.yaml
```

### Proxmox Testing (Production)

- [ ] Proxmox config verified
- [ ] Can access cluster: `kubectl --kubeconfig ~/.kube/proxmox-config get nodes`
- [ ] Bootstrap runs: `make bootstrap CONFIG=config/proxmox.yaml`
- [ ] k6 tests pass
- [ ] Playwright tests pass (or skipped if configured)
- [ ] All tests pass

**Full Verification:**
```bash
make bootstrap CONFIG=config/proxmox.yaml
make test CONFIG=config/proxmox.yaml
```

### Final Release

- [ ] All tests passing
- [ ] Git history is clean (no AI artifacts)
- [ ] Tagged release: `make tag VERSION=1.0`
- [ ] Tag pushed to remote

**Create Release:**
```bash
make clean-claude
git status  # Should be clean
make tag VERSION=1.0
git push origin main --tags
```

---

## Common Issues & Solutions

### Issue: k6 tests fail with "connection refused"

**Solution:**
```bash
# Check if ArgoCD is actually running
kubectl get pods -n argocd
kubectl logs -n argocd deployment/argocd-server

# Check ingress
kubectl get ingress -n argocd
```

### Issue: Playwright tests timeout

**Solution:**
```bash
# Run in headed mode to see what's happening
npm run test:headed

# Check ArgoCD password
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d
```

### Issue: Scripts fail with "command not found"

**Solution:**
```bash
# Make sure all scripts are executable
find . -name "*.sh" -exec chmod +x {} \;

# Source common.sh if needed
source scripts/lib/common.sh
```

### Issue: Can't access Proxmox cluster

**Solution:**
```bash
# Test kubectl access
kubectl --kubeconfig ~/.kube/proxmox-config get nodes

# Check context
kubectl config --kubeconfig ~/.kube/proxmox-config get-contexts

# Update config/proxmox.yaml with correct context name
```

---

## Progress Tracking

**Started:** _______________
**Phase 1 Complete:** _______________
**Phase 5 Complete:** _______________
**Phase 9 Complete:** _______________
**v1.0 Tagged:** _______________

---

## Notes & Observations

Use this space to track issues, decisions, or things to remember:

```
[Date] [Phase] [Note]
Example:
2024-12-21 Phase 4 Changed k6 duration to 60s for better coverage
2024-12-21 Phase 7 Added custom storage class for Proxmox







```

---

## Next Steps After v1.0

Once the bootstrap system is working and trusted:

- [ ] Add your 5 revenue-ready tools to `argocd/apps/`
- [ ] Create k6 tests for each revenue tool
- [ ] Create Playwright E2E tests for each tool's critical path
- [ ] Document tool-specific deployment requirements
- [ ] Set up CI/CD pipeline for automated testing

**The goal:** Get tools deployed and making money, not perfect infrastructure.
